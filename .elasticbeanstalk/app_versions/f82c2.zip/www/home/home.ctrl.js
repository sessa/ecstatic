angular.module('ecstatic.home')

.controller('HomeCtrl', function($scope) {})
