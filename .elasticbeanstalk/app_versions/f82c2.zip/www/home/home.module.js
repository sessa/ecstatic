angular.module('ecstatic.home', [])
