angular.module('ecstatic.playlist')

.controller('PlaylistCtrl', ['$scope',function($scope) {

    // have fun :D
}]);