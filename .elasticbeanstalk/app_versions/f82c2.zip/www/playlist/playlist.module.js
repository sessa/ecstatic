angular.module('ecstatic.playlist', [
])
