angular.module('ecstatic.sockets', ['btford.socket-io', 'ecstatic.player', 'ecstatic.soundcloud', 'ecstatic.config'])
