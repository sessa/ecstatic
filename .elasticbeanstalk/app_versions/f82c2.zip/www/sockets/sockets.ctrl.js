angular.module('ecstatic.sockets')

.controller('SocketsCtrl', ['$scope',function($scope) {

    // have fun :D
}]);
