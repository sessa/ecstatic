angular.module('ecstatic.chat', ['ecstatic.sockets'])
