angular.module('ecstatic.feedback')

.controller('FeedbackCtrl', ['$scope', function($scope) {


}])