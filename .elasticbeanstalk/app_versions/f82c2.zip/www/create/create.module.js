angular.module('ecstatic.create', ['timer'])
