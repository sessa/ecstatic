.controller('soundcloudController', ['$cookies', function($cookies)	{

	
	
}]);