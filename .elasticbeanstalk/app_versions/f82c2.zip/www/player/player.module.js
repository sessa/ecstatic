angular.module('ecstatic.player', [
	'ionic',
	'ecstatic.channels',
	'ecstatic.sockets',       
	'com.2fdevs.videogular',
    'com.2fdevs.videogular.plugins.controls',
    'com.2fdevs.videogular.plugins.overlayplay',
    'com.2fdevs.videogular.plugins.poster'
])
